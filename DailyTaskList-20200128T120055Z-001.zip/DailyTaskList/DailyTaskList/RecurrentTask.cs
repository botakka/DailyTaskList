﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailyTaskList
{
    class RecurrentTask : Task
    {
        public RecurrentTask(int duration, int payment) : base(duration, payment)
        {
            this.Type = IMPORTANCE.RECURRENT;
        }

        public RecurrentTask(RecurrentTask other) : base(other) { }

        public override void DelayIt(string msg)
        {
            throw new TaskDenialException(msg, this);
        }

    }
}
