﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;

namespace DailyTaskList
{
    class Worker
    {
        private const int ONE_SEC = 1000; //ms
        private static System.Timers.Timer aTimer;
        public String UniqueName { get; }
        public ThreadStart threadRef;
        public Thread childThread;
        public Scheduler SchedulerRef { get; set; }
        private static Task actualTask;
        private static Task interruptedTask;
        private static int remainingTimeOfActualtask;
        private static bool interrupted;
        private static List<Task> urgentTasks = new List<Task>();
        private static List<InterruptedTaskRemainingTime> remainingTimes = new List<InterruptedTaskRemainingTime>();
        public bool StopWorking { get; set; }
        public int UrgentTasksIncoming { get => urgentTasks.Count; }
        private bool IsAdHocUrgentTask { get; set; }
        readonly object syncUrgent = new object();
 
        public Worker(String name)
        {
            this.UniqueName = name;
            this.StopWorking = false;
        }

        public void StartToWork()
        {
            this.threadRef = new ThreadStart(DoTheJob);
            this.childThread = new Thread(threadRef);
            Console.WriteLine("Worker : {0} starts to work", UniqueName);
            childThread.Start();
            SetTimer(ONE_SEC/4);
        }

        public void AddUrgentTaskToBackLog(UrgentTask task)
        {
            Task uTask = SchedulerRef.GetTheUrgentTask(task);
            // add to backlog, if it is scheduled
            if (uTask != null)
            {
                urgentTasks.Add(task);
            }
        }

        private void DoTheJob()
        {
            StopWorking = false;
            while (!StopWorking)
            {
                Console.WriteLine("{0} is doing next iteration", UniqueName);
                IsAdHocUrgentTask = false;
                if (UrgentTasksIncoming == 0 && remainingTimes.Count == 0)
                {
                    actualTask = SchedulerRef.GetATaskToDo();
                    if (actualTask != null)
                    {
                        remainingTimeOfActualtask = actualTask.DurationInMins;
                        Console.WriteLine("Starting the {0}", actualTask);
                    }
                    else
                    {
                        if (SchedulerRef.IsReadyToday == true)
                        {
                            SchedulerRef.CleanUp();
                            StopWorking = true;
                            Console.WriteLine("{0} is ready today", UniqueName);
                        }
                    }
                }
                else if (UrgentTasksIncoming > 0)
                {
                    interruptedTask = actualTask;
                    remainingTimeOfActualtask = actualTask != null ? actualTask.DurationInMins : 0;
                    Task urgentTask = SchedulerRef.GetTheUrgentTask(urgentTasks[0]);// get it from the backlog
                    actualTask = SchedulerRef.FindAnUrgentTask((UrgentTask)urgentTask);
                    if (actualTask != null)
                    {
                        lock (syncUrgent)
                        {
                            Monitor.Wait(syncUrgent);
                        }
                        IsAdHocUrgentTask = true;
                        Console.WriteLine("The urgent Task : {0} is starting", actualTask.ToString());
                    }
                }
                else if (remainingTimes.Count > 0)
                {
                    actualTask = SchedulerRef.GetInterruptedTask(remainingTimes[0].TaskId);
                    remainingTimes.RemoveAt(0);
                    if (actualTask != null)
                    {
                        remainingTimeOfActualtask = remainingTimes[0].RemainingTime;
                        interrupted = false;
                        Console.WriteLine("The interrupted Task : {0} is continuing", actualTask);
                    }
                }
                else
                {
                    actualTask = null;
                }

                if (actualTask == null)
                {
                    if (SchedulerRef.IsReadyToday)
                    {
                        StopWorking = true;
                    }
                    if (!StopWorking)
                        Console.WriteLine("{0} is waiting for Task", UniqueName);
                }
                else
                {
                    interrupted = false;
                    while (remainingTimeOfActualtask > 0 && !interrupted)
                    {
                        //the time is accelerated by FACTOR times
                        remainingTimeOfActualtask -= (ONE_SEC / 1000) * Scheduler.FACTOR;
                        Thread.Sleep(ONE_SEC);
                        if (interrupted)
                        {
                            Console.WriteLine("interrupted {0} : {1}", actualTask.ToString(), remainingTimeOfActualtask);
                        }
                    }
                    if (interrupted)
                    {
                        Console.WriteLine("The Task : {0} was interrupted", actualTask);
                        actualTask = null;
                    }
                    else //ready
                    {
                        SchedulerRef.TaskIsReady(actualTask);
                        actualTask.OnTaskFullFillment("Hi Boss this is ready:");
                        SchedulerRef.PrintDailyTasks();
                        Task adHocUrgentTask = urgentTasks.Find(t => t.UniqueId == actualTask.UniqueId);
                        if (adHocUrgentTask != null)
                        {
                            urgentTasks.Remove((UrgentTask)actualTask);
                        }
                        actualTask = null;
                    }
                }
                Thread.Sleep(ONE_SEC);
            }
            if (StopWorking)
                childThread.Abort();
        }

        private void SetTimer(int interval)
        {
            // Create a timer with a one second interval.
            aTimer = new System.Timers.Timer(interval);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            if (urgentTasks.Count > 0 && !IsAdHocUrgentTask)
            {
                NotifyUrgent();
                if (remainingTimeOfActualtask > UrgentTask.MAX_DELAY_OF_URGENT_TASK && !interrupted)
                {
                    interrupted = true;
                    interruptedTask.Interrupted = true;
                    remainingTimes.Add(new InterruptedTaskRemainingTime(interruptedTask.UniqueId, remainingTimeOfActualtask));
                    Console.WriteLine("Interrupted saved {0}, remaining {1}", interruptedTask.ToString(), remainingTimeOfActualtask);
                }
            }
        }

        private void NotifyUrgent()
        {
            lock (syncUrgent)
            {
                Monitor.Pulse(syncUrgent);
            }
        }

        private struct InterruptedTaskRemainingTime
        {
            public long TaskId { get; }
            public int RemainingTime { get; }
            public InterruptedTaskRemainingTime(long id, int time)
            {
                this.TaskId = id;
                this.RemainingTime = time;
            }
        }
    }
}
