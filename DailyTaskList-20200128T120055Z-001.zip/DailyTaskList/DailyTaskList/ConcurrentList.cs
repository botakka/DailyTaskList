﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;

namespace DailyTaskList
{
    public class ConcurrentList<T> : IList<T>
    {
        #region Fields

        private IList<T> _internalList;

        private readonly object lockObject = new object();

        #endregion

        #region ctor

        public ConcurrentList()
        {
            _internalList = new List<T>();
        }

        public ConcurrentList(int capacity)
        {
            _internalList = new List<T>(capacity);
        }

        public ConcurrentList(IEnumerable<T> list)
        {
            _internalList = list.ToList();
        }

        #endregion

        public T this[int index]
        {
            get => LockInternalListAndGet(l => l[index]);

            set => LockInternalListAndCommand(l => l[index] = value);
        }

        public int Count
        {
            get
            {
                return LockInternalListAndQuery(l => l.Count());
            }
        }

        public bool IsReadOnly => false;

        public void Add(T item)
        {
            LockInternalListAndCommand(l => l.Add(item));
        }

        public void Clear()
        {
            LockInternalListAndCommand(l => l.Clear());
        }

        public void Sort()
        {
            LockInternalListAndCommand(l => l.Sort());
        }

        public override string ToString()
        {
            string str = "";
            lock (lockObject)
            {
                
                foreach (T t in _internalList)
                {
                    str += "\t";
                    str += t.ToString();
                    str += Environment.NewLine;
                }
            }
            return str;
        }

        public T Find(Predicate<T> pred)
        {
            return LockInternalListAndGet(l => l.Find(pred));
        }

        public bool Contains(T item)
        {
            return LockInternalListAndQuery(l => l.Contains(item));
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            LockInternalListAndCommand(l => l.CopyTo(array, arrayIndex));
        }

        public IEnumerator<T> GetEnumerator()
        {
            return LockInternalListAndQuery(l => l.GetEnumerator());
        }

        public int IndexOf(T item)
        {
            return LockInternalListAndQuery(l => l.IndexOf(item));
        }

        public void Insert(int index, T item)
        {
            LockInternalListAndCommand(l => l.Insert(index, item));
        }

        public bool Remove(T item)
        {
            return LockInternalListAndQuery(l => l.Remove(item));
        }

        public void RemoveAt(int index)
        {
            LockInternalListAndCommand(l => l.RemoveAt(index));
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return LockInternalListAndQuery(l => l.GetEnumerator());

        }

        #region Utilities

        protected virtual void LockInternalListAndCommand(Action<IList<T>> action)
        {
            lock (lockObject)
            {
                action(_internalList);
            }
        }

        protected virtual void LockInternalListAndCommand(Action<List<T>> action)
        {
            lock (lockObject)
            {
                action((List < T >) _internalList);
            }
        }
        protected virtual T LockInternalListAndGet(Func<IList<T>, T> func)
        {
            lock (lockObject)
            {
                return func(_internalList);
            }
        }

        protected virtual T LockInternalListAndGet(Func<List<T>, T> func)
        {
            lock (lockObject)
            {
                return func((List<T>)_internalList);
            }
        }

        protected virtual TObject LockInternalListAndQuery<TObject>(Func<IList<T>, TObject> query)
        {
            lock (lockObject)
            {
                return query(_internalList);
            }
        }
        #endregion

    }
}