﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DailyTaskList
{
    class Boss
    {
        private static Boss theBoss;
        private const int MAX_URGENT_TASK = 5;
        public ThreadStart threadRef;
        public Thread childThread;
        private bool nextDay;
        public bool StopWorking;
        private List<Worker> workers = new List<Worker>();
        private Dictionary<String, Scheduler> schedulers = new Dictionary<string, Scheduler>();
        private static Random rnd = new Random();
        private List<Task> deniedTasks = new List<Task>();

        public static Boss GetInstance()
        {
            if (theBoss == null)
            {
                theBoss = new Boss();
            }
            return theBoss;
        }

        private Boss()
        {
            this.threadRef = new ThreadStart(DoTheJob);
            this.childThread = new Thread(threadRef);
            nextDay = true;
            StopWorking = false;
        }

        public bool RegisterWorker(Worker aWorker)
        {
            workers.Add(aWorker);
            if (schedulers.ContainsKey(aWorker.UniqueName))
                return false;
            Scheduler scheduler = new Scheduler();
            schedulers.Add(aWorker.UniqueName, scheduler);
            aWorker.SchedulerRef = scheduler;
            return true;
        }

        public void StartToWork()
        {
            childThread.Start();
        }

        private void DoTheJob()
        {
            Random rnd = new Random();
            while (!StopWorking)
            {
                Console.WriteLine("The Boss next iteration");
                bool isAllWorkerReadyToDay = true;
                foreach (Worker worker in workers)
                {
                    Scheduler aScheduler = schedulers[worker.UniqueName];
                    if (nextDay)
                    {
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine("The Boss creates the daily jobs");
                        CreateDailyJobs(aScheduler);
                        nextDay = false;
                        aScheduler.PrintDailyTasks();
                        worker.StartToWork();
                    }
                    else
                    {
                        if (worker.UrgentTasksIncoming < 1 && NeedUrgentTask() && !aScheduler.IsReadyToday)
                        {
                            Task urgentTask = CreateJob(true);
                            aScheduler.AddTask(urgentTask, false);
                            worker.AddUrgentTaskToBackLog((UrgentTask)urgentTask);
                        }
                    }
                    if (aScheduler.IsReadyToday)
                    {
                        worker.StopWorking = true;
                    }
                    isAllWorkerReadyToDay &= schedulers[worker.UniqueName].IsReadyToday;
                    if (isAllWorkerReadyToDay)
                    {
                        nextDay = true;
                        Console.WriteLine("\n\nNext Day");
                    }
                }
                if (!isAllWorkerReadyToDay)
                    Thread.Sleep(5*1000*Scheduler.FACTOR);
            }
            if (StopWorking)
                childThread.Abort();
        }

        public static void TaskIsReady(string msg, Task readyTask)
        {
            Console.Write(msg);
            Console.WriteLine(readyTask.ToString());
        }

        public void GetDeniedTask(TaskDenialException e)
        {
            deniedTasks.Add(e.DTask);
            Console.WriteLine("{0}: {1} was dropped", e.Message, e.DTask);
        }
 
        private static void CreateDailyJobs(Scheduler scheduler)
        {
            List<Task> initialTasks = new List<Task>();
            int tasksToDo = 0;
            foreach (Task task in scheduler.GetDelayedTasks())
            {
                tasksToDo += task.DurationInMins;
                initialTasks.Add(task);
                Console.WriteLine("Boss assigned a delayed : {0}", task.ToString());
            }
            scheduler.GetDelayedTasks().Clear();
            while (tasksToDo < Task.theDayLimit)
            {
                Task aTask = CreateJob(false);
                initialTasks.Add(aTask);
                tasksToDo += aTask.DurationInMins;
            }
            scheduler.AddTasks(initialTasks);
        }

        private static Task CreateJob(bool urgent)
        { 
            int duration = rnd.Next(15, 61);
            duration -= duration % 5;
            int payment = rnd.Next(30, 101);
            payment -= payment % 5;

            int helper = rnd.Next(30);
            IMPORTANCE type = (IMPORTANCE)(helper / 10);
            Task createdTask = null;
            if (urgent)
            {
                createdTask = new UrgentTask(duration, payment);
            }
            else
            {
                switch (type)
                {
                    case IMPORTANCE.NORMAL:
                        createdTask = new NormalTask(duration, payment);
                        break;
                    case IMPORTANCE.URGENT:
                        createdTask = new UrgentTask(duration, payment);
                        break;
                    case IMPORTANCE.RECURRENT:
                        createdTask = new RecurrentTask(duration, payment);
                        break;
                    default:
                        break;
                }
            }
            createdTask.TaskFullfillment += TaskIsReady;
            Console.WriteLine("Boss created : {0}", createdTask.ToString());
            return createdTask;
        }

        private bool NeedUrgentTask()
        {
            int duration = rnd.Next(0, 101);
            if (duration < 60)
                return true;
            else
                return false;
        }

    }
}
