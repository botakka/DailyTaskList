﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DailyTaskList
{
    class Scheduler
    {
        public const int FACTOR = 5;
        public int ThePayment { get; set; }
        private int WorkToDo { get; set; }
        private int NormalTaskDuration { get; set; }
        private int RemainingWorkTodo { get; set; }
        public int WorkDone { get; private set; }
        private ConcurrentList<Task> theNormalTasks = new ConcurrentList<Task>();
        private ConcurrentList<Task> theUrgentTasks = new ConcurrentList<Task>();
        private ConcurrentList<Task> theRecurrentTasks = new ConcurrentList<Task>();
        private ConcurrentList<Task> theDelayedTasks = new ConcurrentList<Task>();
        private ConcurrentList<Task> theRefusedTasks = new ConcurrentList<Task>();
        private Dictionary<IMPORTANCE, ConcurrentList<Task>> theDict = new Dictionary<IMPORTANCE, ConcurrentList<Task>>();
        private bool isReadyToday;
        public bool IsReadyToday { get { return NoMoreTime() || NoMoreTask(); } private set { isReadyToday = value; } }

        public Scheduler()
        {
            this.WorkToDo = 0;
            this.ThePayment = 0;
            this.WorkDone = 0;
            this.IsReadyToday = false;
            this.RemainingWorkTodo = 0;
            this.NormalTaskDuration = 0;
            this.theDict.Add(IMPORTANCE.NORMAL, theNormalTasks);
            this.theDict.Add(IMPORTANCE.URGENT, theUrgentTasks);
            this.theDict.Add(IMPORTANCE.RECURRENT, theRecurrentTasks);
        }

        private void ScheduleIt(Task aTask)
        {
            while (!SchedulingOK())
            {
                try
                {
                    switch (aTask.Type)
                    {
                        case IMPORTANCE.NORMAL:
                            ScheduleNormal(aTask);
                            break;
                        case IMPORTANCE.URGENT:
                        case IMPORTANCE.RECURRENT:
                            ScheduleUrgentOrRecurrent(aTask);
                            break;
                        default:
                            break;
                    }
                }
                catch (TaskDenialException e)
                {
                    Boss.GetInstance().GetDeniedTask(e);
                }
            }
            Console.WriteLine("The tasks after scheduling...");
            PrintDailyTasks();
        }

        private bool SchedulingOK()
        {
            int minDurationNormal = theNormalTasks.Count > 0 ? theNormalTasks[0].DurationInMins : Int32.MaxValue;
            int minDurationUrgent = theUrgentTasks.Count > 0 ? theUrgentTasks[0].DurationInMins : Int32.MaxValue;
            int minDurationRecurrent = theRecurrentTasks.Count > 0 ? theRecurrentTasks[0].DurationInMins : Int32.MaxValue;
            int minDuration = minDurationUrgent < minDurationRecurrent ? minDurationUrgent : minDurationRecurrent;
            minDuration = minDuration < minDurationNormal ? minDuration : minDurationNormal;
            //no more task
            if (minDuration == Int32.MaxValue)
                return false;
            //workingtime is not enough to finish the task
            if (minDuration > Task.theDayLimit - WorkDone)
                return false;
            //exceeds the working time, get shorten
            if (Task.theDayLimit < RemainingWorkTodo + WorkDone)
                return false;
            return true;
        }

        public void AddTasks(List<Task> tasks)
        {
            foreach (Task item in tasks)
            {
                AddTask(item, true);
            }
        }

        public void AddTask(Task aTask, bool init)
        {
            if (!init && RemainingWorkTodo <= aTask.DurationInMins)
                return;
            ConcurrentList<Task> theList = theDict[aTask.Type];
            theList.Add(aTask);
            theList.Sort();

            WorkToDo += aTask.DurationInMins;
            RemainingWorkTodo += aTask.DurationInMins;
            ThePayment += aTask.Payment;
            if (aTask is NormalTask)
            {
                NormalTaskDuration += aTask.DurationInMins;
            }
            if (WorkToDo > Task.theDayLimit || RemainingWorkTodo + WorkDone > Task.theDayLimit)
            {
                ScheduleIt(aTask);
            }
        }

        private Task GetTaskLessThan(int maxLength, int index, ConcurrentList<Task> cList)
        {
            if (index == 0)
            {
                return cList[0].DurationInMins < maxLength ? cList[0] : null;
            }
            else 
            {
                return cList[index].DurationInMins < maxLength ? cList[index] : GetTaskLessThan(maxLength, --index, cList);
            }
        }

        public Task GetTheUrgentTask(Task aTask)
        {
            return theUrgentTasks.Find(t => t.Equals(aTask));
        }

        public Task GetInterruptedTask(long id)
        {
            Task task = GetInterruptedTask(id, IMPORTANCE.URGENT);
            if (task == null)
            {
                task = GetInterruptedTask(id, IMPORTANCE.RECURRENT);
                if (task == null)
                {
                    task = GetInterruptedTask(id, IMPORTANCE.NORMAL);
                }
            }
            return task;
        }

        private Task GetInterruptedTask(long  id, IMPORTANCE type)
        {
            return theDict[type].Find(t => t.UniqueId == id);
        }

        public Task GetATaskToDo()
        {
            int maxDuration = Task.theDayLimit - WorkDone;
            Task maxPrioTask = MaxPriorityTask();
            Task nTask = null;
            if (maxPrioTask == null)
            {
                nTask = theNormalTasks.Count > 0 ? GetTaskLessThan(maxDuration, theNormalTasks.Count - 1, theNormalTasks) : null;
            }
            else
            {
                nTask = maxPrioTask;
            }
            Task uTask = theUrgentTasks.Count > 0 ? GetTaskLessThan(maxDuration, theUrgentTasks.Count - 1, theUrgentTasks) : null;
            Task rTask = theRecurrentTasks.Count > 0 ? GetTaskLessThan(maxDuration, theRecurrentTasks.Count - 1, theRecurrentTasks) : null;
            Task maxTask = null;
            if (uTask != null)
                maxTask = uTask;
            else if (rTask != null)
                maxTask = rTask;
            else if (nTask != null)
                maxTask = nTask;

            //sanity check
            if (maxTask == null)
            {
                Task deniedTask = null;
                if (theNormalTasks.Count > 0)
                {
                    deniedTask = theNormalTasks[0];
                }
                else if (theUrgentTasks.Count > 0)
                {
                    deniedTask = theUrgentTasks[0];
                }
                else if (theRecurrentTasks.Count > 0)
                {
                    deniedTask = theRecurrentTasks[0];
                }
                if (deniedTask != null)
                { 
                    theDict[deniedTask.Type].RemoveAt(0);
                    deniedTask.DelayIt("Hi Boss, I ran out of time!");
                }
            }
  
            return maxTask;
        }

        private bool ReplaceTask(Task insert, Task drop)
        {
            if (insert == null || drop == null)
                return false;
            ConcurrentList<Task> theInsertList = theDict[insert.Type];
            ConcurrentList<Task> theDropList = theDict[drop.Type];
            if (insert.Equals(drop))
            {
                theDropList.Remove(drop);
                DelayTask(drop);
                return false;
            }
            Task InsertedTask = theInsertList.Find(t => t.Equals(insert));
            if (InsertedTask == null)
            {
                theInsertList.Add(insert);
                theInsertList.Sort();
                WorkToDo += insert.DurationInMins;
                RemainingWorkTodo += insert.DurationInMins;
            }
            else
            {
                Console.WriteLine("By replacing  it {0} was not inserted", insert.ToString());
            }
            theDropList.Remove(drop);
            WorkToDo = WorkToDo < drop.DurationInMins ? 0 : WorkToDo - drop.DurationInMins;
            RemainingWorkTodo = RemainingWorkTodo < drop.DurationInMins ? 0 : RemainingWorkTodo - drop.DurationInMins;
            DelayTask(drop);
            Console.WriteLine("{0} replaced to {1}", drop.ToString(), insert.ToString());
            Console.WriteLine("WorkDone : {0} remaining work to do: {1}", WorkDone.ToString(), RemainingWorkTodo.ToString());
            return true;
        }

        private void DelayTask(Task aTask)
        {
            aTask.DelayIt(null);
            theDelayedTasks.Add(aTask);
            theDelayedTasks.Sort();
        }

        private void ScheduleNormal(Task aTask)
        {
            if (aTask.Type != IMPORTANCE.NORMAL)
                return;
            Console.WriteLine("Schedule a Normal : {0}", aTask.ToString());
            Task theTask = theNormalTasks[0];
            if (theTask == null)
            {
                DelayTask(aTask);
                return;
            }
            if (ReplaceTask(aTask, theTask))//normal task does not throws exception by delaying it
            {
                NormalTaskDuration -= theTask.DurationInMins;
                NormalTaskDuration += aTask.DurationInMins;
            }
        }

        private void ScheduleUrgentOrRecurrent(Task aTask)
        {
            if (aTask.Type != IMPORTANCE.URGENT && aTask.Type != IMPORTANCE.RECURRENT)
                return;
            Task nTask = theNormalTasks.Count > 0 ? theNormalTasks[0] : null;// get the minimal or null
            Task taskToDrop = null;
            if (nTask == null)
            {
                Task rTask = theRecurrentTasks.Count > 0 ? theRecurrentTasks[0] : null;
                Task uTask = theUrgentTasks.Count > 0 ? theUrgentTasks[0] : null;
                if (rTask != null && uTask != null)
                {
                    taskToDrop = rTask.Payment > uTask.Payment ? uTask : rTask;
                }
                else if (rTask != null)
                {
                    taskToDrop = rTask;
                }
                else if (uTask != null)
                {
                    taskToDrop = uTask;
                }
                else
                {
                    taskToDrop = aTask;
                    theDict[taskToDrop.Type].Add(taskToDrop);
                }
                ConcurrentList<Task> theList = theDict[taskToDrop.Type];
                theRefusedTasks.Add(taskToDrop);
                theList.Remove(taskToDrop);
                WorkToDo += aTask.DurationInMins;
                WorkToDo = WorkToDo < taskToDrop.DurationInMins ? 0 : WorkToDo - taskToDrop.DurationInMins;
                RemainingWorkTodo += aTask.DurationInMins;
                RemainingWorkTodo = RemainingWorkTodo < taskToDrop.DurationInMins ? 0 : RemainingWorkTodo - taskToDrop.DurationInMins;
                throw new TaskDenialException("Hi Boss, I could not do this task!", taskToDrop);
            }
            ReplaceTask(aTask, nTask);
        }

        public UrgentTask FindAnUrgentTask(UrgentTask aTask)
        {
            Task uTask = theUrgentTasks.Find(delegate (Task t)
            {
                return t.Equals(aTask);
            });
            return (UrgentTask)uTask;
        }

        public void TaskIsReady(Task task)
        {
            theDict[task.Type].Remove(task);
            RemainingWorkTodo = RemainingWorkTodo < task.DurationInMins ? 0 : RemainingWorkTodo - task.DurationInMins;
            WorkDone += task.DurationInMins;
            if (task.Type == IMPORTANCE.NORMAL)
            {
                NormalTaskDuration -= task.DurationInMins;
            }
            ThePayment += task.Payment;
        }

        private bool NoMoreTime()
        {
            int nTime = theNormalTasks.Count > 0 ? theNormalTasks.Max(t => t.DurationInMins) : 0;
            int uTime = theUrgentTasks.Count > 0 ? theUrgentTasks.Max(t => t.DurationInMins) : 0;
            int rTime = theRecurrentTasks.Count > 0 ? theRecurrentTasks.Max(t => t.DurationInMins) : 0;
            List<int> times = new List<int> { nTime, uTime, rTime }; 
            return RemainingWorkTodo < times.Max();
        }

        private bool NoMoreTask()
        {
            return theNormalTasks.Count == 0 && theUrgentTasks.Count == 0 && theRecurrentTasks.Count == 0;
        }

        public void CleanUp()
        {
            foreach (Task item in theNormalTasks)
            {
                item.DelayIt(null);
                theDelayedTasks.Add(item);
            }
            foreach (Task item in theUrgentTasks)
            {
                theRefusedTasks.Add(item);
            }
            foreach (Task item in theRecurrentTasks)
            {
                theRefusedTasks.Add(item);
            }
            ThePayment = 0;
            WorkToDo = 0;
            NormalTaskDuration = 0;
            RemainingWorkTodo = 0;
            WorkDone = 0;
            theNormalTasks.Clear();
            theUrgentTasks.Clear();
            theRecurrentTasks.Clear();
        }

        public ConcurrentList<Task> GetDelayedTasks()
        {
            return theDelayedTasks;
        }

        private Task MaxPriorityTask()
        {
            int maxPrio = 0;
            Task maxPrioTask = null;
            foreach (Task item in theNormalTasks)
            {
                if (maxPrio < ((NormalTask)item).Priority)
                {
                    maxPrio = ((NormalTask)item).Priority;
                    maxPrioTask = item;
                }
            }
            return maxPrioTask;
        } 

        public void PrintDailyTasks()
        {
            Console.WriteLine("The Daily Tasks");
            Console.WriteLine(theUrgentTasks.ToString());
            Console.WriteLine(theRecurrentTasks.ToString());
            Console.WriteLine(theNormalTasks.ToString());
            Console.WriteLine("\tRemainingWorkTodo: {0}, WorkDone: {1}", RemainingWorkTodo, WorkDone);
            if (theDelayedTasks.Count > 0)
            {
                Console.WriteLine("\tDelayed tasks are:");
                Console.WriteLine(theDelayedTasks.ToString());
            }
            Console.WriteLine();
        }
    }
}
