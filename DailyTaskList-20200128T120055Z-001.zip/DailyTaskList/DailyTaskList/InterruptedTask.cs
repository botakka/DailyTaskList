﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailyTaskList
{
    public class InterruptedTask : Task
    {
        public int RemainingDuration { get; set; }
        public Task TaskToBeContinue { get; }
        public InterruptedTask(Task other) : base(other)
        {
            this.TaskToBeContinue = other;
        }

        public override void DelayIt()
        {
        }
    }
}
