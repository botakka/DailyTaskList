﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DailyTaskList
{
    public class TaskDenialException : Exception
    {
        public Task DTask { get; }
        public TaskDenialException(string message, Task aTask) : base(message)
        {
            this.DTask = aTask;
        }
    }
}
