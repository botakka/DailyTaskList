﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailyTaskList
{
    class NormalTask : Task
    {
        public int Priority { get; set; }

        public NormalTask(int duration, int payment) : base(duration, payment)
        {
            this.MustBeDoneToday = false;
            this.Type = IMPORTANCE.NORMAL;
        }

        public NormalTask(NormalTask other) : base(other) { }

        public override void DelayIt(string msg)
        {
            ++Priority;
            Delayed = true;
            Console.WriteLine("the {0} is delayed", ToString());
        }

    }
}
