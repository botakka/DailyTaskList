﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DailyTaskList
{
    class Program
    {
        private static bool keepRunning = true;
        static void Main(string[] args)
        {
            Console.CancelKeyPress += delegate (object sender, ConsoleCancelEventArgs e) {
                e.Cancel = true;
                keepRunning = false;
            };
 
            Console.WriteLine("press Ctrl+C to exit");
            Boss boss = Boss.GetInstance();
            Worker worker1 = new Worker("BusyBuddy");
            boss.RegisterWorker(worker1);
            boss.StartToWork();
            while (keepRunning)
            {
                Thread.Sleep(1000);
            }
            worker1.StopWorking = true;
            boss.StopWorking = true;
            Console.WriteLine("exited gracefully");
        }
    }
}
