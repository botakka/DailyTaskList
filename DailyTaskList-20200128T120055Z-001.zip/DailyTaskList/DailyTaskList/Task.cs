﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailyTaskList
{
    public enum IMPORTANCE
    {
        NORMAL = 0,
        URGENT,
        RECURRENT
    }

    public abstract class Task : IComparable<Task>, IEquatable<Task>
    {
        public delegate void BossInformerHandler(string msg, Task readyTask);
        public event BossInformerHandler TaskFullfillment;
        public const int theDayLimit = 480;
        public IMPORTANCE Type { get; protected set; }
        public bool Delayed { get; set; } = false;// only in normal task
        public bool MustBeDoneToday { get; set; } = true;
        private static long Counter = 0;
        public long UniqueId { get; private set; }
        public bool Interrupted { get; set; } = false;

        public int Payment { get; set; }
        public int DurationInMins { get; set; }

        public abstract void DelayIt(string msg);

        public Task(int duration, int payment)
        {
            this.DurationInMins = duration;
            this.Payment = payment;
            this.UniqueId = Counter >= Int64.MaxValue ? 0 : Counter++;
        }

        public Task(Task other)
        {
            this.DurationInMins = other.DurationInMins;
            this.Payment = other.Payment;
            this.Type = other.Type;
            this.Delayed = other.Delayed;
            this.MustBeDoneToday = other.MustBeDoneToday;
            this.UniqueId = other.UniqueId;
            this.Interrupted = other.Interrupted;
        }

        public int CompareTo(Task other)
        {
            if (other == null)
                return 1;
            return this.Payment.CompareTo(other.Payment);
        }

        public bool Equals(Task other)
        {
            if (other == null)
            {
                return false;
            }
            else
            {
                return (other.Payment == Payment) && (other.DurationInMins == DurationInMins) &&
                    (other.Type == Type) && (other.UniqueId == UniqueId) && (other.Interrupted == Interrupted);
            }
        }

        public override string ToString()
        {
            string str = "Task => id " + UniqueId + ", type " + Type + ", duration: " + DurationInMins + ", payment: " + Payment;
            return str;
        }

        public void OnTaskFullFillment(string msg)
        {
            TaskFullfillment?.Invoke(msg, this);
        }
    }
}
