﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailyTaskList
{
    class UrgentTask : Task
    {
        public const int MAX_DELAY_OF_URGENT_TASK = 30;
        public UrgentTask(int duration, int payment) : base(duration, payment)
        {
            this.Type = IMPORTANCE.URGENT;
        }

        public UrgentTask(UrgentTask other) : base(other) { }

        public override void DelayIt(string msg)
        {
            throw new TaskDenialException(msg, this);
        }

    }
}
